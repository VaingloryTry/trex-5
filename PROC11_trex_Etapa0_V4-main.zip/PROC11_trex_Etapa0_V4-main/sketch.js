
var trex ,trex_running;
function preload(){
  

}

function setup(){
  createCanvas(600,200)
  
  //crear sprite de Trex
 
}

function draw(){
  background("white")
  

}
